export { WindowContextProvider, useWindowContext } from '@/app/components/window/WindowContext'
export { TitlebarContextProvider, useTitlebarContext } from '@/app/components/window/TitlebarContext'
export { menuItems } from './titlebarMenus'
